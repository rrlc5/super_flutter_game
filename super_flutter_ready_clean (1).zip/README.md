# Super Flutter Game

This is the final packaged version of the Super game with Firebase and AdMob.